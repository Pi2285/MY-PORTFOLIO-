import 'package:flutter/material.dart';

void main() => runApp(const MyPortfolioApp());

class MyPortfolioApp extends StatelessWidget {
  const MyPortfolioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My portfolio',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const Myportfoliopage(),
    );
  }
}

class Myportfoliopage extends StatelessWidget {
  const Myportfoliopage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'my portfolio',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: Color(0xff441081),
          ),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xffeaffe5),
      ),
      body: Container(
        padding: const EdgeInsets.all(16.0),
        color: const Color(0xffec106b),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const CircleAvatar(
              radius: 20,
              backgroundImage: AssetImage('assest/siddhi18.jpg'),
            ),
            const SizedBox(height: 15),
            const Text(
              'SIDDHI',
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
                color: Color(0xffffffff),
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'I AM A FIRST YEAR COMPUTER SCIENCE STUDENT....PERSUING MY GRADUATION FROM MATA SUNDARI COLLEGE, LEARNING VARIOUS PROGRAMMING LANGUAGES. I AM EGEAR TO ENCAPSULATE CODDING AND APP BUILDING SKILLS. I USED TO EXPLORE THE DEPTH OF AI AND LEARNING NEW SKILLS TO BUILD UP MY STRENGTH. I AM FAMILIER WITH PROGRAMMING LANGUAGES LIKE PYTHON, JAVA & C++.... AND NOW I AM SEEKING FOR AN OPPORTUNITY TO WORK ON VARIOUS PROJECTS.',
              style: TextStyle(
                fontSize: 16,
                color: Color(0xffffffff),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Skills:',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xffffffff),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                _buildSkillItem('PYTHON', context),
                _buildSkillItem('JAVA', context),
                _buildSkillItem('C++', context),
              ],
            ),
            const SizedBox(height: 15),
            const SizedBox(height: 15),
            const Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Icon(Icons.email, color: Color(0xffcfd345)),
                SizedBox(width: 5),
                Text(
                  'oneplus1311@gmail.com',
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xffcfd345),
                  ),
                ),
              ],
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Icon(Icons.phone, color: Colors.yellow),
                SizedBox(width: 5),
                Text(
                  '+91 9310942678',
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xffcfd345),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSkillItem(String skill, BuildContext context) {
    return InkWell(
      onTap: () {
        if (skill == 'PYTHON') {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text(
                    'learning highlevel programming recently and studied basics in 11th and 12th')),
          );
        }
      },
      child: Container(
        padding: const EdgeInsets.all(8.0),
        margin: const EdgeInsets.symmetric(horizontal: 8.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Text(
          skill,
          style: const TextStyle(
            fontSize: 18,
            color: Colors.blue,
            fontWeight: FontWeight.bold,
          ), // TextStyle
        ),
      ),
    );
  }
}
